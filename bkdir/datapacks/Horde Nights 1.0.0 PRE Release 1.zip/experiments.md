# 1.20.5 Experiments

- Horders increase in size
  - Using the generic.scale attribute, mobs in the horde get slightly bigger
  - Supports 1.20.5 PRE1(Datapack Format 39)
- 1.20.5 Re-Write
  - A beta testing version of updating to the breaking changes in 1.20.5
  - Supports 1.20.5 PRE1(Datapack Format 39)

# 1.21 Experiments

- The Bogged
  - Recruited The Bogged into the Horde
  - Added some of the new potion effects to specific Mobs of the Horde.
  - Supports 1.20.5 PRE1(Datapack Format 39)